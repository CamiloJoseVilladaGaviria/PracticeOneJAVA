/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package navetur;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Yates extends Embarcacion {
    Yates() {
        super();
        toStringEmbarcacion((ArrayList) Capitan, precioBase, valorAdicional, anioFabricacion, eslora);
    valorAdicional(valorAdicional);
    montoAlquiler(precioBase, anioFabricacion);
    }
    
    public int cantidadCamarotes;
    
    public String compararYates(int cantidadCamarotes) {
        this.cantidadCamarotes = cantidadCamarotes;
        if (this.cantidadCamarotes > cantidadCamarotes) {
            return "El primero es mayor: " + this.cantidadCamarotes;
        } else {
            return "El segundo es mayor: " + cantidadCamarotes;
        }
    }
}
