/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package navetur;

/**
 *
 * @author ASUS
 */
public class Navetur {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Capitan capitan = new Capitan();
        System.out.println(capitan.Capitan("Carlos", "Villagran", "222"));
        System.out.println("////////////////////////////////////////////////////");
        Veleros veleros = new Veleros();
        System.out.println(veleros);
        System.out.println("////////////////////////////////////////////////////");
        Yates yates = new Yates();
        System.out.println(yates);
    }

}
