/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package navetur;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ASUS
 */
public abstract class Embarcacion {

    public List<String> Capitan;
    public double precioBase;
    public double valorAdicional;
    public int anioFabricacion;
    public double eslora;

    public String toStringEmbarcacion(ArrayList Capitan, double precioBase, double valorAdicional, int anioFabricacion, double eslora) {
        this.Capitan = new ArrayList<>(2);
        this.precioBase = precioBase;
        this.valorAdicional = valorAdicional;
        this.anioFabricacion = anioFabricacion;
        this.eslora = eslora;
        return "Capitan: " + Capitan + "\n" + "Precio Base: " + precioBase + "\n"
                + "Anio Fabricacion: " + anioFabricacion + "\n"
                + "Eslora: " + eslora;
    }

    public String valorAdicional(double valorAdicional) {
        this.valorAdicional = valorAdicional;
        return "Valor Adicional: " + valorAdicional;
    }

    public String montoAlquiler(double precioBase, int anioFabricacion) {
        int anio = 2020;
        this.precioBase = precioBase;
        this.anioFabricacion = anioFabricacion;
        if (anioFabricacion > anio) {
            double totalUno = precioBase + valorAdicional;
            return "Resultado y aplica para Valor Adicional: " + "$" + totalUno;
        } else {
            return "Resultado y NO aplica para Valor Adicional: " + "$" + precioBase;
        }
    }

}
   

