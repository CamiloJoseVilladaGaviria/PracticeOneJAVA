/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package navetur;

/**
 *
 * @author ASUS
 */
public class Capitan extends Veleros {

    Capitan() {
        super();

        for (String capitan : Capitan) {
            System.out.println(capitan);
        }
    }
    private String nombre;
    private String apellido;
    public String matricula;

    public String Capitan(String nombre, String apellido, String matricula) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.matricula = matricula;

        return "Nombre: " + nombre + "\n"
                + "Apellido: " + apellido + "\n"
                + "Matricula: " + matricula;
    }

    public String getNombreCapitan(String nombre) {
        return this.nombre;
    }

    public String getApellidoCapitan(String apellido) {
        return this.apellido;
    }
}
