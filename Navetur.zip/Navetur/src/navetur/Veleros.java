/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package navetur;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Veleros extends Embarcacion {

    Veleros() {
        super();

        toStringEmbarcacion((ArrayList) Capitan, precioBase, valorAdicional, anioFabricacion, eslora);
        valorAdicional(valorAdicional);
        montoAlquiler(precioBase, anioFabricacion);
    }
    public int cantidadMastiles;

    public String evaluarVeleros(int cantidadMastiles) {
        this.cantidadMastiles = cantidadMastiles;
        if (this.cantidadMastiles > cantidadMastiles) {
            return "El primero es mayor: " + this.cantidadMastiles;
        } else {
            return "El segundo es mayor: " + cantidadMastiles;
        }
    }

}
    

